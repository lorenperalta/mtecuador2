<li class="nav-item">
    <a class="nav-link" href="<?= site_url('Cliente') ?>">CLIENTE</a>
</li>
<li class="nav-item">
    <a class="nav-link" href="<?= site_url('DetalleCliente') ?>">DETALLE CLIENTES</a>
</li>
<li class="nav-item">
    <a class="nav-link" href="<?= site_url('Suscripcion') ?>">SUSCRIPCIONES</a>  
</li>