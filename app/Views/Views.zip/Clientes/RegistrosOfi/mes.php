<?= $this->extend('Layout/ClienteDash') ?>
<?= $this->section('contenido') ?>

<div class="container">
    <h1 class="display-4">Registros Oficiales <?php echo $datos ?></h1><br>

    <div class="row">
        <div class="col-sm">
            <a href=""> <i class="fa fa-folder" style="font-size:90px;color:#ffc107"></i><br></a>
            <label for="">Enero</label>
        </div>
        <div class="col-sm">
            <a href=""> <i class="fa fa-folder" style="font-size:90px;color:#ffc107"></i><br></a>
            <label for="">Febrero</label>
        </div>
        <div class="col-sm">
            <a href=""> <i class="fa fa-folder" style="font-size:90px;color:#ffc107"></i><br></a>
            <label for="">Marzo</label>
        </div>
        <div class="col-sm">
            <a href=""> <i class="fa fa-folder" style="font-size:90px;color:#ffc107"></i><br></a>
            <label for="">Abril</label>
        </div>
    </div>
    <div class="row">
        <div class="col-sm">
            <a href=""> <i class="fa fa-folder" style="font-size:90px;color:#ffc107"></i><br></a>
            <label for="">Mayo</label>
        </div>
        <div class="col-sm">
            <a href=""> <i class="fa fa-folder" style="font-size:90px;color:#ffc107"></i><br></a>
            <label for="">Junio</label>
        </div>
        <div class="col-sm">
            <a href=""> <i class="fa fa-folder" style="font-size:90px;color:#ffc107"></i><br></a>
            <label for="">Julio</label>
        </div>
        <div class="col-sm">
            <a href=""> <i class="fa fa-folder" style="font-size:90px;color:#ffc107"></i><br></a>
            <label for="">Agosto</label>
        </div>
    </div>
    <div class="row">
        <div class="col-sm">
            <a href=""> <i class="fa fa-folder" style="font-size:90px;color:#ffc107"></i><br></a>
            <label for="">Setiembre</label>
        </div>
        <div class="col-sm">
            <a href=""> <i class="fa fa-folder" style="font-size:90px;color:#ffc107"></i><br></a>
            <label for="">Octubre</label>
        </div>
        <div class="col-sm">
            <a href=""> <i class="fa fa-folder" style="font-size:90px;color:#ffc107"></i><br></a>
            <label for="">Noviembre</label>
        </div>
        <div class="col-sm">
            <a href=""> <i class="fa fa-folder" style="font-size:90px;color:#ffc107"></i><br></a>
            <label for="">Diciembre</label>
        </div>
    </div>

</div>
<?= $this->endSection() ?>